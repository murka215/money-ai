# Crypto Copy Lab — iPhone browser edition

## What this is
A single-file, browser-only research and paper-trading prototype. It does not connect to an exchange, does not place real orders, and does not need API keys. Demo records are fictional.

## Open on iPhone
1. Download `index.html` and `README.txt` from this package.
2. In Safari, open the HTML file from the Files app if your iOS version allows local HTML previews. If Safari doesn't run it as an interactive page, upload `index.html` to a GitHub repository and enable GitHub Pages, or use a browser-based static-hosting service. Do not publish private exports.
3. Open the hosted page in Safari. No build step or package installation is required.

## Research period
The app screens records for 18 July 2026 through 18 October 2026. It deliberately does not claim a live leaderboard snapshot proves performance for the entire period. Populate the metrics CSV with source data covering the full period.

## Trader metrics CSV
Required headers:
`trader,source,window_start,window_end,roi90_pct,max_drawdown_pct,trades90,active_days90`
Optional:
`roi30_pct,roi7_pct,win_rate_pct,avg_leverage,verified,notes`

- `window_start` and `window_end` should cover the full requested window.
- `roi90_pct` and `max_drawdown_pct` are percentages, e.g. `12` means 12%.
- The score is a transparent heuristic, not a validated forecast.
- The starter screens out >10x average leverage and drawdown >=40%; tune filters only with care.
- Official platform metrics can use different ROI formulas. Preserve source and retrieval date in your own notes.

## Trade CSV
Required headers:
`timestamp,trader,symbol,side,price,quantity`
Optional `trade_id`.
- Timestamp should be ISO 8601, ideally UTC (e.g. `2026-09-01T10:00:00Z`).
- Side is BUY or SELL.
- Quantity and price are the source trader's values.
- This starter only models long-only spot-like BUY/SELL flows. It does not model shorts, leverage, funding, liquidations, order books, partial fills or accurate unrealized P&L.
- A missing/late/private trade feed cannot be copied by this tool.

## Known limitations
- No automatic leaderboard scraper or exchange API integration in this browser-only prototype.
- No persistence guarantee: data may disappear when the page/browser session is cleared.
- Trade window is filtered relative to the current device clock.
- Slippage and network delays are not simulated. Backtests/paper results are not proof of future profits.
- The loss stop is a simplified cash-balance check and does not include unrealized open-position losses.
- Never paste secrets into CSV or this page.

## Official research references
- Binance trader comparison FAQ: https://www.binance.com/en/support/faq/detail/607c124c574a417bbf734f9035ee9d28
- Binance copy trading guide: https://www.binance.com/en/academy/articles/your-guide-to-binance-copy-trading
- Bybit master trader ranking criteria: https://www.bybit.global/en/help-center/article/How-Can-Master-Traders-Rank-in-The-Different-Categories
- Bitget copy trading API documentation: https://bitget.ac/docs/catalog/copy-trading
- Bitget ROI calculation update: https://www.bitget.com/support/articles/12560603885593


## Quick start
- Keep this in paper mode: it does not connect to an exchange, place live trades, or request API keys.
- Starting real-money capital is $0. The virtual paper balance is simulated money, not a deposit; adjust it in Settings & CSV.
- To test the interface, open Settings & CSV, tap “Load fictional demo dataset,” then open Paper trades. Demo traders and trades are fictional.
- To use real historical research, import verified trader-metrics and timestamped-trade CSVs. The app does not automatically collect public trader data.
- GitHub Pages hosts the static page; it does not run a 24/7 process or a Python backend.
